#!/bin/bash
cd Virgo
python3 create_table.py

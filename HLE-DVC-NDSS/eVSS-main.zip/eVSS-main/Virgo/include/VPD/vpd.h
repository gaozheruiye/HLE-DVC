#ifndef __vpd
#define __vpd

#include "infrastructure/constants.h"
#include "infrastructure/RS_polynomial.h"
#include "infrastructure/merkle_tree.h"

namespace vpd
{

}

#endif
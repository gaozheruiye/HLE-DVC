#pragma once
int mylog(long long x);
int min(int x, int y);
int max(int x, int y);
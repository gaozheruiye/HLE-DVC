#!/bin/bash

cd KZG_ext
python3 create_table.py
